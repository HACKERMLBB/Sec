import sqlite3
from pathlib import Path


class Database:
    def __init__(self, path: Path):
        self.path = str(path)

    def connect(self):
        con = sqlite3.connect(self.path, timeout=30)
        con.execute("PRAGMA journal_mode=WAL")
        return con

    def initialize(self):
        with self.connect() as con:
            con.execute("""
                CREATE TABLE IF NOT EXISTS links (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    url TEXT NOT NULL UNIQUE,
                    created_at TEXT DEFAULT CURRENT_TIMESTAMP
                )
            """)

    def add_link(self, url: str) -> int:
        with self.connect() as con:
            cur = con.execute("INSERT OR IGNORE INTO links(url) VALUES (?)", (url,))
            if cur.lastrowid:
                return cur.lastrowid
            row = con.execute("SELECT id FROM links WHERE url=?", (url,)).fetchone()
            return int(row[0])

    def list_links(self):
        with self.connect() as con:
            return [(int(row[0]), row[1]) for row in
                    con.execute("SELECT id, url FROM links ORDER BY id")]

    def remove_link(self, link_id: int):
        with self.connect() as con:
            con.execute("DELETE FROM links WHERE id=?", (link_id,))
