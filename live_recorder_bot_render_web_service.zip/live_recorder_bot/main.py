import asyncio
import json
import logging
import os
import re
import shlex
import signal
from pathlib import Path
from urllib.parse import urlparse

from telegram import Update
from telegram.constants import ParseMode
from telegram.ext import (
    Application, CommandHandler, ContextTypes,
)

from database import Database
from mixdrop import MixdropClient
from health_server import start_health_server

logging.basicConfig(
    level=os.getenv("LOG_LEVEL", "INFO"),
    format="%(asctime)s %(levelname)s %(name)s: %(message)s",
)
log = logging.getLogger("live-recorder")

BOT_TOKEN = os.environ["TELEGRAM_BOT_TOKEN"]
OWNER_IDS = {
    int(x.strip()) for x in os.getenv("OWNER_USER_IDS", "").split(",")
    if x.strip()
}
CHANNEL_ID = os.getenv("TELEGRAM_CHANNEL_ID", "").strip()
MIXDROP_EMAIL = os.getenv("MIXDROP_EMAIL", "").strip()
MIXDROP_KEY = os.getenv("MIXDROP_KEY", "").strip()
DATA_DIR = Path(os.getenv("DATA_DIR", "/var/data"))
RECORD_DIR = DATA_DIR / "recordings"
DB_PATH = DATA_DIR / "bot.sqlite3"
POLL_SECONDS = max(15, int(os.getenv("POLL_SECONDS", "30")))
MAX_RECORDINGS = max(1, int(os.getenv("MAX_CONCURRENT_RECORDINGS", "2")))
HEIGHT = int(os.getenv("MAX_HEIGHT", "480"))

db = Database(DB_PATH)
active_tasks: dict[int, asyncio.Task] = {}
active_processes: dict[int, asyncio.subprocess.Process] = {}
recording_slots = asyncio.Semaphore(MAX_RECORDINGS)


def is_owner(update: Update) -> bool:
    user = update.effective_user
    return bool(user and user.id in OWNER_IDS)


async def deny(update: Update):
    if update.effective_message:
        await update.effective_message.reply_text(
            "මෙම bot එක භාවිතා කිරීමට අවසර නැහැ. Bot ownerගෙන් access ලබාගන්න."
        )


def valid_http_url(value: str) -> bool:
    try:
        parsed = urlparse(value)
        return parsed.scheme in ("http", "https") and bool(parsed.netloc)
    except Exception:
        return False


def safe_filename(value: str) -> str:
    value = re.sub(r"[^A-Za-z0-9._-]+", "_", value).strip("._")
    return (value or "live_recording")[:90]


async def run_ytdlp_json(url: str) -> dict | None:
    proc = await asyncio.create_subprocess_exec(
        "yt-dlp", "--dump-single-json", "--skip-download",
        "--no-warnings", "--no-playlist", "--socket-timeout", "20",
        "--retries", "1", url,
        stdout=asyncio.subprocess.PIPE,
        stderr=asyncio.subprocess.PIPE,
    )
    try:
        stdout, stderr = await asyncio.wait_for(proc.communicate(), timeout=50)
    except asyncio.TimeoutError:
        proc.kill()
        await proc.communicate()
        return None
    if proc.returncode != 0 or not stdout:
        log.debug("Metadata check failed: %s", stderr.decode(errors="replace")[-500:])
        return None
    try:
        return json.loads(stdout.decode("utf-8", errors="replace"))
    except json.JSONDecodeError:
        return None


async def upload_and_post(app: Application, path: Path, info: dict):
    client = MixdropClient(MIXDROP_EMAIL, MIXDROP_KEY)
    result = await client.upload(path)
    file_url = result.get("url")
    fileref = result.get("fileref")
    if not file_url and fileref:
        file_url = f"https://mixdrop.ag/f/{fileref}"
    if not file_url:
        raise RuntimeError("Mixdrop API did not return a file URL")

    title = info.get("title") or path.stem
    thumb = result.get("thumb") or info.get("thumbnail")
    caption = (
        f"<b>{escape_html(str(title))}</b>\n\n"
        f"🎬 <a href=\"{escape_html(file_url)}\">Watch on Mixdrop</a>"
    )
    if CHANNEL_ID:
        try:
            if thumb:
                await app.bot.send_photo(
                    chat_id=CHANNEL_ID, photo=thumb,
                    caption=caption, parse_mode=ParseMode.HTML,
                )
            else:
                await app.bot.send_message(
                    chat_id=CHANNEL_ID, text=caption,
                    parse_mode=ParseMode.HTML, disable_web_page_preview=False,
                )
        except Exception:
            log.exception("Could not post to Telegram channel")
            raise
    return file_url


def escape_html(value: str) -> str:
    return (value.replace("&", "&amp;").replace("<", "&lt;")
            .replace(">", "&gt;").replace('"', "&quot;"))


async def record_one(app: Application, link_id: int, url: str):
    async with recording_slots:
        RECORD_DIR.mkdir(parents=True, exist_ok=True)
        info = await run_ytdlp_json(url)
        if not info:
            log.warning("Could not read stream metadata for link %s", link_id)
            return
        title = safe_filename(info.get("title") or f"link_{link_id}")
        output_template = str(RECORD_DIR / f"link{link_id}_{title}.%(ext)s")
        cmd = [
            "yt-dlp", "--no-warnings", "--no-playlist",
            "-f", f"best[height<={HEIGHT}]/bestvideo[height<={HEIGHT}]+bestaudio",
            "--merge-output-format", "mp4",
            "--write-thumbnail", "--write-info-json",
            "--output", output_template,
            "--retries", "10", "--fragment-retries", "10",
            "--socket-timeout", "30",
            url,
        ]
        proc = await asyncio.create_subprocess_exec(
            *cmd,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.STDOUT,
        )
        active_processes[link_id] = proc
        try:
            stdout, _ = await proc.communicate()
            log.info("yt-dlp finished for link %s, exit=%s: %s",
                     link_id, proc.returncode,
                     stdout.decode(errors="replace")[-1200:])
        except asyncio.CancelledError:
            if proc.returncode is None:
                proc.terminate()
                try:
                    await asyncio.wait_for(proc.wait(), timeout=8)
                except asyncio.TimeoutError:
                    proc.kill()
                    await proc.wait()
            raise
        finally:
            active_processes.pop(link_id, None)

        if proc.returncode != 0:
            log.warning("Recording failed for link %s", link_id)
            return

        candidates = sorted(
            RECORD_DIR.glob(f"link{link_id}_{title}.*"),
            key=lambda p: p.stat().st_mtime,
            reverse=True,
        )
        video = next((p for p in candidates
                      if p.suffix.lower() in (".mp4", ".mkv", ".webm", ".mov")), None)
        info_file = next((p for p in candidates if p.suffix == ".json"), None)
        if info_file:
            try:
                info = json.loads(info_file.read_text(encoding="utf-8"))
            except Exception:
                pass
        if not video:
            log.error("No output video found for link %s", link_id)
            return
        try:
            link = await upload_and_post(app, video, info)
            log.info("Uploaded link %s to Mixdrop: %s", link_id, link)
        except Exception:
            log.exception("Upload/post failed for link %s", link_id)


async def monitor_loop(app: Application):
    log.info("Monitor started; polling every %s seconds", POLL_SECONDS)
    while True:
        try:
            for link_id, url in db.list_links():
                task = active_tasks.get(link_id)
                if task and not task.done():
                    continue
                info = await run_ytdlp_json(url)
                if info and (info.get("is_live") is True or
                             info.get("live_status") == "is_live"):
                    log.info("Live detected for link %s", link_id)
                    task = asyncio.create_task(record_one(app, link_id, url))
                    active_tasks[link_id] = task
                    task.add_done_callback(
                        lambda done, lid=link_id:
                        active_tasks.pop(lid, None) if active_tasks.get(lid) is done else None
                    )
        except asyncio.CancelledError:
            raise
        except Exception:
            log.exception("Monitor loop error")
        await asyncio.sleep(POLL_SECONDS)


async def post_init(app: Application):
    app.create_task(monitor_loop(app), name="live-monitor")


async def start_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not is_owner(update):
        return await deny(update)
    await update.effective_message.reply_text(
        "Live Recorder Bot සූදානම්.\n"
        "/add URL - authorized live link එකතු කරන්න\n"
        "/list - links බලන්න\n"
        "/remove ID - link ඉවත් කරන්න\n"
        "/status - monitor/recording තත්ත්වය\n"
        "/stop ID - දැනට record වන link එක නවත්වන්න\n"
        "/help - උදව්"
    )


async def help_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await start_cmd(update, context)


async def add_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not is_owner(update):
        return await deny(update)
    if not context.args:
        return await update.effective_message.reply_text("භාවිතය: /add https://...")
    url = context.args[0].strip()
    if not valid_http_url(url):
        return await update.effective_message.reply_text("නිවැරදි http/https URL එකක් දෙන්න.")
    link_id = db.add_link(url)
    await update.effective_message.reply_text(
        f"Link #{link_id} එකතු කළා. Live වුණාම monitor කර record කරනවා."
    )


async def list_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not is_owner(update):
        return await deny(update)
    links = db.list_links()
    if not links:
        return await update.effective_message.reply_text("තවම links නැහැ.")
    lines = [f"#{lid} — {url}" for lid, url in links]
    await update.effective_message.reply_text("\n".join(lines))


async def remove_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not is_owner(update):
        return await deny(update)
    if not context.args or not context.args[0].isdigit():
        return await update.effective_message.reply_text("භාවිතය: /remove ID")
    lid = int(context.args[0])
    task = active_tasks.get(lid)
    if task and not task.done():
        task.cancel()
    db.remove_link(lid)
    await update.effective_message.reply_text(f"Link #{lid} ඉවත් කළා.")


async def stop_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not is_owner(update):
        return await deny(update)
    if not context.args or not context.args[0].isdigit():
        return await update.effective_message.reply_text("භාවිතය: /stop ID")
    lid = int(context.args[0])
    task = active_tasks.get(lid)
    if not task or task.done():
        return await update.effective_message.reply_text(f"Link #{lid} record වෙන්නේ නැහැ.")
    task.cancel()
    await update.effective_message.reply_text(f"Link #{lid} recording නවත්වන්න ඉල්ලුවා.")


async def status_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not is_owner(update):
        return await deny(update)
    links = db.list_links()
    running = [lid for lid, task in active_tasks.items() if not task.done()]
    await update.effective_message.reply_text(
        f"Monitoring links: {len(links)}\n"
        f"Active recordings: {len(running)}"
        + (f"\nRecording IDs: {', '.join(map(str, running))}" if running else "")
    )


def main():
    # Render Web Services require an HTTP listener on the assigned PORT.
    health_server = start_health_server()
    log.info("Health server listening on 0.0.0.0:%s", os.getenv("PORT", "10000"))
    if not OWNER_IDS:
        raise RuntimeError("Set OWNER_USER_IDS to your numeric Telegram user ID.")
    if not MIXDROP_EMAIL or not MIXDROP_KEY:
        raise RuntimeError("Set MIXDROP_EMAIL and MIXDROP_KEY.")
    if not CHANNEL_ID:
        raise RuntimeError("Set TELEGRAM_CHANNEL_ID.")
    RECORD_DIR.mkdir(parents=True, exist_ok=True)
    db.initialize()

    app = (Application.builder()
           .token(BOT_TOKEN)
           .post_init(post_init)
           .build())
    app.add_handler(CommandHandler("start", start_cmd))
    app.add_handler(CommandHandler("help", help_cmd))
    app.add_handler(CommandHandler("add", add_cmd))
    app.add_handler(CommandHandler("list", list_cmd))
    app.add_handler(CommandHandler("remove", remove_cmd))
    app.add_handler(CommandHandler("stop", stop_cmd))
    app.add_handler(CommandHandler("status", status_cmd))
    app.run_polling(drop_pending_updates=True)


if __name__ == "__main__":
    main()
