import asyncio
from pathlib import Path
import aiohttp


class MixdropClient:
    UPLOAD_URL = "https://ul.mixdrop.ag/api"
    API_BASE = "https://api.mixdrop.ag"

    def __init__(self, email: str, key: str):
        self.email = email
        self.key = key

    async def upload(self, file_path: Path) -> dict:
        timeout = aiohttp.ClientTimeout(total=None, sock_connect=60, sock_read=600)
        data = aiohttp.FormData()
        data.add_field("email", self.email)
        data.add_field("key", self.key)
        with file_path.open("rb") as file_handle:
            data.add_field(
                "file", file_handle,
                filename=file_path.name,
                content_type="video/mp4",
            )
            async with aiohttp.ClientSession(timeout=timeout) as session:
                async with session.post(self.UPLOAD_URL, data=data) as response:
                    response.raise_for_status()
                    payload = await response.json(content_type=None)

        if not payload.get("success"):
            raise RuntimeError(f"Mixdrop upload failed: {payload}")
        result = payload.get("result") or {}
        fileref = result.get("fileref")
        url = result.get("url")
        thumb = None
        if fileref:
            thumb = await self.get_thumbnail(fileref)
        return {"fileref": fileref, "url": url, "thumb": thumb}

    async def get_thumbnail(self, fileref: str) -> str | None:
        params = [
            ("email", self.email),
            ("key", self.key),
            ("ref[]", fileref),
        ]
        timeout = aiohttp.ClientTimeout(total=30)
        try:
            async with aiohttp.ClientSession(timeout=timeout) as session:
                async with session.get(
                    f"{self.API_BASE}/fileinfo2", params=params
                ) as response:
                    response.raise_for_status()
                    payload = await response.json(content_type=None)
            result = payload.get("result") or {}
            item = result.get(fileref) if isinstance(result, dict) else None
            return item.get("thumb") if isinstance(item, dict) else None
        except Exception:
            return None
