# Live Recorder Telegram Bot

Python Telegram bot for monitoring multiple **authorized** livestream URLs,
recording them at up to 480p, uploading completed files to Mixdrop, and posting
the Mixdrop link plus a thumbnail to a Telegram channel.

Use this only for streams you own or have explicit permission to record and
redistribute. Follow the source platform's terms, copyright rules, and
Mixdrop's terms. The bot does not bypass logins, DRM, paywalls, or access
controls.

## Features

- `/add URL` add an authorized stream
- `/list` list monitored links
- `/remove ID` remove a link
- `/status` show active recordings
- `/stop ID` stop a recording
- Detects live streams using yt-dlp metadata
- Concurrent monitoring and configurable concurrent recordings
- MP4 output, capped at 480p when the source offers that format
- Mixdrop upload through its documented multipart API
- Posts the Mixdrop URL and available Mixdrop thumbnail to the channel

## 1. Create Telegram bot and channel

1. Create a bot using Telegram's official BotFather and copy its token.
2. Create a Telegram channel.
3. Add the bot to that channel as an administrator with permission to post.
4. Set `TELEGRAM_CHANNEL_ID` to `@channelusername` or the channel's numeric ID.
5. Find your own numeric Telegram user ID and set it as `OWNER_USER_IDS`.
   Only IDs in this variable can control the bot.

Do not share the bot token or Mixdrop API key. If either is exposed, rotate it.

## 2. Mixdrop credentials

Get the API email and API key from your own Mixdrop account settings. The
uploader uses the Mixdrop multipart upload endpoint documented at
https://mixdrop.ag/api/ (upload endpoint: `https://ul.mixdrop.ag/api`).

## 3. Deploy to GitHub + Render

1. Create a private GitHub repository and upload these project files.
2. In Render, choose **New + → Blueprint** and connect that repository. The Blueprint creates a **Web Service** (not a Background Worker), with an HTTP health endpoint listening on Render's assigned `PORT`.
3. Render reads `render.yaml`. Enter all environment variables marked
   `sync: false` in the Render dashboard.
4. Deploy the Background Worker.
5. Check the worker logs for startup errors.
6. Open the Telegram bot and send `/start`.

The included Render plan uses a paid Background Worker and a persistent disk.
A persistent disk is important: recordings and SQLite data are stored under
`/var/data`. Check Render's current pricing and disk limits before deploying.
The configured disk is 20 GB; monitor usage and increase it if needed.

## 4. Environment variables

| Variable | Meaning |
|---|---|
| `TELEGRAM_BOT_TOKEN` | Bot token |
| `OWNER_USER_IDS` | Comma-separated numeric Telegram user IDs allowed to control it |
| `TELEGRAM_CHANNEL_ID` | Channel username or numeric ID |
| `MIXDROP_EMAIL` | Mixdrop API email |
| `MIXDROP_KEY` | Mixdrop API key |
| `DATA_DIR` | Persistent data directory |
| `POLL_SECONDS` | Live-check interval (minimum 15 seconds) |
| `MAX_CONCURRENT_RECORDINGS` | Maximum simultaneous recordings |
| `MAX_HEIGHT` | Maximum requested video height; default 480 |

## 5. Local run (optional)

Install Python 3.12, ffmpeg, and yt-dlp, then:

```bash
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
# Fill in .env, then export its variables into your shell.
python main.py
```

On Windows, activate the virtual environment with
`.venv\\Scripts\\activate`.

## Notes and limitations

- yt-dlp supports many sites, but not every livestream provider or URL.
- Some streams require cookies or login. This starter project deliberately
  does not automate authentication or bypass restrictions.
- If a live stream disconnects, yt-dlp may exit; the monitor checks again and
  can start a new recording while the stream is still live.
- The thumbnail is taken from Mixdrop's file-info API when available; otherwise
  the source's public thumbnail is used.
- Large livestream recordings can exceed disk space or Mixdrop upload limits.
  Check storage and account limits. The example does not automatically delete
  local files, so add a retention policy only after deciding what you need.
- Render Web Services and persistent disks have plan-specific limits. A free
  web service is not a reliable 24/7 recorder.
- For security, keep the GitHub repository private and never commit `.env`,
  tokens, API keys, cookies, or private stream URLs.
